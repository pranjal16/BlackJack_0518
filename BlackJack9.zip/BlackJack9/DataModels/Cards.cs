﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    public class Cards
    {
        //change to private
        public string[] cards = null;
        public int top = -1;

        public Cards()
        {
            string[] suits = { "Heart", "Diamond", "Spade", "Club" };
            cards = new string[52];
            int curr = 0;

            for (int i = 0; i < suits.Length; i++)
            {
                for (int j = 1; j <= 13; j++)
                {
                    cards[curr] = j + " " + suits[i];
                    curr++;
                }
            }

            top = curr-1;

            Deal();

        }

        public void Shuffle(int loc, Random rnd) 
        {
            if(loc<0 || loc >= cards.Length || rnd==null)
            {
                throw new ArgumentException("0");
            }
            if(loc==0)
            {
                return;
            }
            else
            {
                Shuffle(loc - 1, rnd);
                int existLoc = rnd.Next(0, (loc - 1));
                Swap(existLoc, loc);
            }

        }

        private void Swap(int loc1, int loc2)
        {
            string temp = this.cards[loc1];
            this.cards[loc1] = this.cards[loc2];
            this.cards[loc2] = temp;
        }

        public string GetTopCard()
        {
            if (IsEmpty())
            {
                throw new ArgumentException("1");
            }
            else
            {
                this.top--;
                return this.cards[(this.top+1)];
            }
        }
        private Boolean IsEmpty()
        {
            return top < 0;
        }

        //Added later re-think seperation
        //TODO object sender PARAM


        //changed to public
        public int GetCardNumber(string card)
        {
            if (card == null || card.Length == 0)
            {
                throw new ArgumentException("2");
            }
            else
            {
                return int.Parse(card.Substring(0, card.IndexOf(' ')));

            }
        }
        public void Deal()
        {
            Random rnd = new Random();
            int Total = 52;
            try
            {
                this.Shuffle(Total - 1, rnd);
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Unexpected Error in Shuffle!, Please press end game! ");
            }
        }


    }
}

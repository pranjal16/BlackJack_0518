﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    public class Dealer
    {
        //TODO make private , //catch exceptions thrown
        public int Total = 90;
        public string lastMove="";

        public void SaveLastMove(string lastMove)
        {
            this.lastMove = lastMove;
        }

        public string DealerPickcard(Cards cards)
        {
            string topCard = "";
            try
            {
                topCard = cards.GetTopCard();

                int no = cards.GetCardNumber(topCard);
                if (no == 1 && ((Total + 11 == 21) || ((Total + 11 <= 16) && !(Total + 11 > 21))))
                {
                    this.Total += 11;
                }
                else
                {
                    this.Total += no;
                }
                this.SaveLastMove("Hit");
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Unexpected Error in Dealer Hit!, Please press end game! ");
            }
            return topCard;
        }

        public String GetAutoDealermove()
        {
            //May be consider players last move, random choose to Stand if has advantage
            /* Consider players last move if it's stand and if player's Total > Dealers take 
             * a guess at Hit
             */
            String Dealermove = "";
            if (this.Total >= 17)
            {
                Dealermove = "Stand";
            }
            else
            {
                Dealermove = "Hit";
            }
            return Dealermove;
        }

        public int GetTotal()
        {
            return this.Total;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    public class Player
    {
        //TODO make private
        public int Total = 10;
        private string _lastMove="";
        public string Name = "";
        public Player()
        {
            this.Name = "Player";
        }
        public void SaveLastMove(string move)
        {
            this._lastMove = move;   
        }

        public string GetLastMove()
        {
            return this._lastMove;
        }

        public string PlayerPickcard(Cards cards)
        {
            string topCard = "";
            try
            {
                topCard = cards.GetTopCard();
                int no = cards.GetCardNumber(topCard);
                if (no == 1 && ((Total + 11 == 21) || ((Total + 11 <= 16) && !(Total + 11 > 21))))
                {
                    this.Total += 11;
                }
                else
                {
                    this.Total += no;
                }
                this.SaveLastMove("Hit");
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Unexpected Error in Player Hit!, Please press end game! ");
            }
            return topCard;
        }

        public int GetTotal()
        {
            return this.Total;
        }
    }
}

﻿using System;

namespace BlackJack
{
    public class TrackAndDisplay
    {
        public string Winner = null;
        private string _imagePath1 = "";
        private string _imagePath2 = "";
        private string _imagePath3 = "";
        private string _imagePath4 = "";
        private string _pimagePath = "";
        private string _dimagePath = "";

        //nc
        public static int Round = 0;
        public int R1P = 0;
        public int R1D = 0;
        public int R2P = 0;
        public int R2D = 0;
        public int R3P = 0;
        public int R3D = 0;
        private static int _playerWins = 0;
        private static int _dealerWins = 0;

        public TrackAndDisplay()
        {
            Winner = "";
            ResetCardImages();
        }
        public string CheckGamestatus(Player player, Dealer dealer)
        {
            //corner case both lost
            if (player.Total > 21 && dealer.Total > 21)
            {
                 Winner="none";
            }

            else
            {
                if (player.Total == 21 || dealer.Total > 21)
                {
                    Winner = "Player";
                }

                else if(dealer.Total == 21 || player.Total > 21)
                {
                    if (Winner.Length > 0)
                    {
                        Winner += "and Dealer";
                    }
                    else
                    {
                        Winner = "Dealer";

                    }
                }
                else
                {
                    Winner = "";
                }

            }

            return Winner;
        }

        public void GameReset(Player player, Dealer dealer)
        {
            player.Total = 0;
            dealer.Total = 0;
            ResetCardImages();

        }

        public void ResetCardImages()
        {
                _pimagePath = "Images\\BlankSlot.JPG";  
                _dimagePath = "Images\\BlankSlot.JPG";
                _imagePath1 = "Images\\BlankSlot.JPG";
                _imagePath2 = "Images\\BlankSlot.JPG";
                _imagePath3 = "Images\\BlankSlot.JPG";
                _imagePath4 = "Images\\BlankSlot.JPG";
    }
        public string GetClosestToWin(Player player, Dealer dealer)
        {
            int pDiff = (21- player.Total);
            int dDiff = (21 - dealer.Total);

            if(pDiff< dDiff)
            {
                Winner = "Player";
            }
            else if(dDiff < pDiff)
            {
                Winner = "Dealer";
            }
            else
            {
                Winner = "Player and Dealer";
            }

            return Winner;
        }

        public void SetImagePathPick(int param,String topCard)
        {
            if(param==1)
            { 
                _pimagePath ="Images\\" + topCard + ".JPG";
            }
            else
            {
                _dimagePath = "Images\\" + topCard + ".JPG";
            }
        }

        public string GetImagePath(int param)
        {
            if (param == 1)
            {
                return _pimagePath;
            }
            else
            {
                return _dimagePath;
            }
        }

        public string GetImagePathSpec(int param)
        {
            if(param==1)
            {
                return this._imagePath1;
            }
            else if(param==2)
            {
                return this._imagePath2;
            }
            else if(param==3)
            {
                return this._imagePath3;
            }
            else
            {
                return this._imagePath4;
            }
        }
        public void SetImagePath(int param, String value)
        {
            if (param == 1)
            {
                this._imagePath1 = value;
            }
            else if(param == 2)
            {
                this._imagePath2 = value;
            }
            else if (param == 3)
            {
                this._imagePath3 = value;
            }
            else 
            {
                this._imagePath4 = value;
            }
        }

        public void SetWinner(Info i,string Winner, Player player, Dealer dealer,bool win)
        {
            if(win)
            { 
                i.Message = "Congratulations :" + Winner + " you won the game!Totals: Player " + player.GetTotal().ToString() + " Dealer " + dealer.GetTotal().ToString();
                this.Winner = Winner;
            }
            else
            {
                i.Message = "Game over : Sorry we don't have a winner this time!Please try again!";
            }

            if(Round==1)
            {
                R1P= player.GetTotal();
                R1D= dealer.GetTotal();
            }
            else if (Round == 2)
            {
                R2P = player.GetTotal();
                R2D = dealer.GetTotal();
            }
            else 
            {
                R3P = player.GetTotal();
                R3D = dealer.GetTotal();
            }

            UpdateMatchWins(Winner, win);
        }

        public void SetMessage(Info i, string message)
        {
            i.Message=message;
        }

        public void IncrementRound()
        {
            Round++;
        }

        public int GetRound()
        {
            return Round;
        }

        public string GetWinner()
        {
            if(Round!=3)
            {
                return "";
            }
            else
            {
                SetWinner();
                return Winner;
            }
            
        }
        
        private void UpdateMatchWins(string Winner, bool win)
        {
            if (win)
            {
                if (Winner.Equals("Player") || Winner.Length > 6)
                {
                    _playerWins++;
                }
                if (Winner.Equals("Dealer") || Winner.Length > 6)
                {
                    _dealerWins++;
                }
            }

        }

        //red
        public void SetWinner()
        {
            if (_playerWins > 0 && _dealerWins > 0)
            {
                if (_playerWins > _dealerWins)
                {
                     Winner="Player";
                }
                else if (_playerWins < _dealerWins)
                {
                     Winner="Dealer";
                }
                else
                {
                    Winner="Player and Dealer";
                }
            }
            else
            {
                    Winner="";
            }
        }

        public int GetPlayerWins()
        {
            return _playerWins;
        }

        public int GetDealerWins()
        {
            return _dealerWins;
        }
    }
}

﻿using BlackJack.ViewModels.ViewModelComponents;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;

namespace BlackJack.ViewModels
{
    // USE CARDS ISEMPTY FOR ERROR //catch exceptions thrown
    // USE flag HERE to stop after round 3
    public class MyViewModel: INotifyPropertyChanged
    {
        private ICommand _showButtonCommand;
        private ICommand _pickButtonCommand;
        private ICommand _standButtonCommand;
        private bool _canExecute = true;
        Cards cards = null;
        Player player = null;
        Dealer Dealer = null;
        DealClass DealClass = null;
        TrackAndDisplay trackAndDisplay = null;
        Info i;
        private string _messageFetched;
        private bool _isDeal;
        int topmost;
        private bool _canPick;
        private bool _canReset;

        public event PropertyChangedEventHandler PropertyChanged;
        public ICommand CloseWindowCommand { get; private set; }
        public MyViewModel()
        {
            instantiateGame();
        }

        private void instantiateGame()
        {
            cards = new Cards();
            player = new Player();
            Dealer = new Dealer();
            trackAndDisplay = new TrackAndDisplay();
            DealClass = null;
            _isDeal = true;
            _canPick = true;
            notifyUI("Dealcards");
            ShowButtonCommand = new RelayCommand(ShowMessage, param => this._canExecute);
            CloseWindowCommand = new RelayCommand<ICloseable>(CloseWindow);
            //PickACard
            PickButtonCommand = new RelayCommand(PickACard, param => this._canPick);
            StandButtonCommand = new RelayCommand(StandACard, param => this._canPick);
            i = new Info
            {
                Message = "Welcome!"

            };
            _messageFetched = "Sample";
            _isDeal = false;
            topmost = 0;
            _canPick = false;
            _canReset = false;
        }
        private void StandACard(object obj)
        {
            try
            {
                trackAndDisplay.SetMessage(i, "Player choses Stand!");
                ShowMessage(this);
                player.SaveLastMove("Stand");
                String Dealermove = Dealer.GetAutoDealermove();
                trackAndDisplay.SetMessage(i, "Dealer choses " + Dealermove + "!");
                ShowMessage(this);
                if (Dealermove.Equals("Stand"))
                {
                    string winner = trackAndDisplay.GetClosestToWin(player, Dealer);
                    trackAndDisplay.SetWinner(i, winner, player, Dealer, true);
                    _canReset = true;
                    this.GameReset();
                }
                else
                {
                    string topCard = Dealer.DealerPickcard(cards);
                    trackAndDisplay.SetMessage(i, "Picked card " + topCard);
                    ShowMessage(this);
                    Boolean result = CheckEndOfGame();
                    if (!result)
                    {
                        trackAndDisplay.SetImagePathPick(2, topCard);
                        notifyUI("Dealer");
                    }
                    else
                    {
                        _canReset = true;
                        this.GameReset();
                    }

                }
            }
            catch (Exception ex)
            {
                trackAndDisplay.SetMessage(i, "Unexpected Error in Waiving move!, Please press end game! ");
                ShowMessage(this);
            }
        }

        private void PickACard(object obj)
        {
            try
            {
                trackAndDisplay.SetMessage(i, "Player choses Hit!");
                ShowMessage(this);
                string topCard = player.PlayerPickcard(cards);
                trackAndDisplay.SetMessage(i, "Picked card " + topCard);
                ShowMessage(this);
                Boolean result = CheckEndOfGame();
                trackAndDisplay.SetImagePathPick(1, topCard);
                notifyUI("player");
                if (!result)
                {
                    String Dealermove = Dealer.GetAutoDealermove();
                    trackAndDisplay.SetMessage(i, "Dealer choses " + Dealermove + "!");
                    ShowMessage(this);
                    if (Dealermove.Equals("Hit"))
                    {
                        topCard = Dealer.DealerPickcard(cards);
                        trackAndDisplay.SetMessage(i, "Picked card " + topCard);
                        ShowMessage(this);
                        result = CheckEndOfGame();
                        if (result)
                        {
                            _canReset = true;
                            this.GameReset();
                        }
                        else
                        {
                            trackAndDisplay.SetImagePathPick(2, topCard);
                            notifyUI("Dealer");
                        }

                    }
                }
                else
                {
                    _canReset = true;
                    this.GameReset();
                }

            }
            catch (Exception ex)
            {
                trackAndDisplay.SetMessage(i, "Unexpected Error in Waiving move!, Please press end game! ");
                ShowMessage(this);
            }
        }

        public bool CanExecute
        {
            get
            {
                return this._canExecute;
            }

            set
            {
                if (this._canExecute == value)
                {
                    return;
                }

                this._canExecute = value;
            }
        }

        public string Message
        {
            get
            {
                return _messageFetched;
            }
            set
            {
                _messageFetched = value;
                i.Message = value;
                OnPropertyRaised("Message");
            }
        }
        
        public ICommand DealCommand
        {
            get
            {
                try
                { 
                trackAndDisplay.IncrementRound();
                dealCards();
                }
                catch(Exception ex)
                {
                    trackAndDisplay.SetMessage(i, "Unexpected Error in Dealing Cards!, Please press end game! ");
                    ShowMessage(this);

                }
                return null; // Change later
            }

        }

        private void dealCards()
        {
            _isDeal = true;
            notifyUI("Dealcards");

            DealClass = new DealClass(cards, player, Dealer);
            topmost = cards.cards.Length - 1;
            int no1 = cards.GetCardNumber(cards.cards[topmost]);
            int no2 = cards.GetCardNumber(cards.cards[topmost - 1]);
            int no3 = cards.GetCardNumber(cards.cards[topmost - 2]);
            int no4 = cards.GetCardNumber(cards.cards[topmost - 3]);

            no1 = this.RefactorCard1(no1, no2);

            no3 = this.RefactorCard1(no3, no4);

            no2 = this.RefactorCard2(no1, no2);

            no4 = this.RefactorCard2(no3, no4);

            player.Total = no1 + no2;
            Dealer.Total = no3 + no4;

            cards.top = topmost - 4;
            notifyUI("Totals");

            Boolean result = CheckEndOfGame();
            if (result)
            {
                this._canReset = true;
            }
            else
            {
                _canPick = true;
            }

        }
        private Boolean CheckEndOfGame()
        {
            Boolean result = false;
            string winner = trackAndDisplay.CheckGamestatus( this.player,  this.Dealer);
            if (winner.Length > 0)
            {
                if(!winner.Equals("none"))
                { 
                    trackAndDisplay.SetWinner(i, winner, player, Dealer,true);
                }
                else
                {
                    trackAndDisplay.SetWinner(i, winner, player, Dealer, false);
                }
                result = true;
                
                if(!this._canReset && !this._canPick)
                {
                    this._canReset = true;
                }
            }

            if ((_canReset || _canPick) && result)
            {
                this.GameReset();
            }
            
            return result;
        }
        public void GameReset()
        {
            if(_canReset)
            {
                ShowMessage(this);
                trackAndDisplay.GameReset(this.player, this.Dealer);
                _isDeal = false;
                notifyUI("Dealcards");
                notifyUI("Totals"); 
                int currentRound = trackAndDisplay.GetRound();
                if(currentRound==1)
                { 
                    notifyUI("Scoreboard1");
                }
                else if(currentRound==2)
                {
                    notifyUI("Scoreboard2");
                }
                else
                {
                    notifyUI("Scoreboard3");
                    notifyUI("Winner");
                }
  
                    trackAndDisplay.SetMessage(i, "Do you wish to continue playing?");
                    ShowMessageChoice(this, currentRound);
           
            }
        }

        public ICommand PickButtonCommand
        {
            get
            {
                return _pickButtonCommand;
            }
            set
            {
                _pickButtonCommand = value;

            }
        }

        public ICommand StandButtonCommand
        {
            get
            {
                return _standButtonCommand;
            }
            set
            {
                _standButtonCommand = value;

            }
        }
        private int RefactorCard1(int card1,int card2)
        {
            if (card1 == 1)
            {
                if (card2 != 1)
                {
                    if ((11 + card2) <= 16 || (11 + card2) == 21)
                    {
                        return 11;
                    }
                    else
                    {
                        return 1;
                    }

                }
                else
                {
                    return card1;
                }
            }
            else
            {
                return card1;
            }
        }

        private int RefactorCard2(int card1, int card2)
        {
            if (card2 == 1)
            {
                if ((card1 + 11) <= 16 || (card1 + 11) == 21)
                {
                    return 11;
                }
                else
                {
                    return 1;
                }
            }
            else
            {
                return card2;
            }
        }

        public ICommand ShowButtonCommand
        {
            get
            {
                return _showButtonCommand;                   
            }
            set
            {
                _showButtonCommand = value;
            }
        }
        
        public string Pcard1
        {
            get
            {
                if (!_isDeal)
                {
                    return trackAndDisplay.GetImagePathSpec(1);
                }
                else
                {
                    trackAndDisplay.SetImagePath(1,GetImageLoc(cards.cards.Length - 1));
                    return trackAndDisplay.GetImagePathSpec(1);
                }

            }
            set
            {
                trackAndDisplay.SetImagePath(1, value);
            }
        }

        public string Pcard2
        {
            get
            { 
                if (!_isDeal)
                {
                    return trackAndDisplay.GetImagePathSpec(2);
                }
                else
                {
                    trackAndDisplay.SetImagePath(2, GetImageLoc(cards.cards.Length - 2));
                    return trackAndDisplay.GetImagePathSpec(2);
                }

            }
            set
            {
                trackAndDisplay.SetImagePath(2, value);
            }
        }

        public string Dcard1
        {
            get
            {
                if (!_isDeal)
                {
                    return trackAndDisplay.GetImagePathSpec(3);
                }
                else
                {
                    trackAndDisplay.SetImagePath(3, GetImageLoc(cards.cards.Length - 3));
                    return trackAndDisplay.GetImagePathSpec(3);
                }

            }
            set
            {
                trackAndDisplay.SetImagePath(3, value);
            }
        }


        public string Dcard2
        {
            get
            {
                if (!_isDeal)
                {
                    return trackAndDisplay.GetImagePathSpec(4);
                }
                else
                {
                    trackAndDisplay.SetImagePath(4, GetImageLoc(cards.cards.Length - 4));
                    return trackAndDisplay.GetImagePathSpec(4);
                }

            }
            set
            {
                trackAndDisplay.SetImagePath(4, value);
            } 
        }


        public string Pcard
        {
             
            get
            {
                return trackAndDisplay.GetImagePath(1);

            }
            set
            {
                trackAndDisplay.SetImagePathPick(1,value);
            } 
        }

        public string Dcard
        {
             
            get
            {
                return trackAndDisplay.GetImagePath(2);

            }
            set
            {
                trackAndDisplay.SetImagePathPick(2, value);
            } 
        }
        public string GetImageLoc(int topmost)
        {
            return "Images\\"+cards.cards[topmost]+".JPG";
        }
        public void ShowMessage(object obj)
        {
            System.Windows.MessageBox.Show(i.Message, "Info", MessageBoxButton.OK);
        }

        public void ShowMessageChoice(object obj,int currentRound)
        {
            if(currentRound == 3)
            {
                int playerwins = trackAndDisplay.GetPlayerWins();
                int dealerwins = trackAndDisplay.GetDealerWins();

                string grouplayerwinsinner = ((playerwins > dealerwins) ? "Player":(dealerwins > playerwins) ? "Dealer": "Player And Dealer");
                var selectedOption = System.Windows.Forms.MessageBox.Show("Congratulations "+ grouplayerwinsinner+" you won the Set. Player wins :"+ playerwins+ " Dealer wins :" + dealerwins+" ", "Info", (MessageBoxButtons)MessageBoxButton.OK);
                trackAndDisplay = new TrackAndDisplay();
                notifyUI("Scoreboard1");
                notifyUI("Scoreboard2");
                notifyUI("Scoreboard3");
                notifyUI("Winner");
                notifyUI("Total");
            }
            else
            { 
                    var selectedOption=System.Windows.Forms.MessageBox.Show(i.Message, "Info", (MessageBoxButtons)MessageBoxButton.YesNoCancel);
                    if(selectedOption == DialogResult.Yes)
                    {
                        trackAndDisplay.IncrementRound();
                        trackAndDisplay.SetMessage(i, "Resetting the game again! Round :" + trackAndDisplay.GetRound());
                        ShowMessage(this);
                        instantiateGame();
                        dealCards();
                    }
                    else if(selectedOption == DialogResult.No)
                    {
                        System.Windows.Application.Current.Shutdown();
                    }
                    else
                    {
                        trackAndDisplay.SetMessage(i, "Please Press End Game to exit!");
                        ShowMessage(this);
                        this._canPick = false;
                        _canExecute = false;
                }

            }
        }

        public string PlayerTotal
        {
            get
            {
                return player.Total.ToString();
            }
            set
            {
                player.Total = int.Parse(value);
            }
        }

        public string R1P
        {
            get
            {
                return trackAndDisplay.R1P.ToString();
            }
            set
            {
                trackAndDisplay.R1P = int.Parse(value);
            }
        }

        public string R2P
        {
            get
            {
                return trackAndDisplay.R2P.ToString();
            }
            set
            {
                trackAndDisplay.R2P = int.Parse(value);
            }
        }

        public string R3P
        {
            get
            {
                return trackAndDisplay.R3P.ToString();
            }
            set
            {
                trackAndDisplay.R3P = int.Parse(value);
            }
        }


        public string R1D
        {
            get
            {
                return trackAndDisplay.R1D.ToString();
            }
            set
            {
                trackAndDisplay.R1D = int.Parse(value);
            }
        }

        public string R2D
        {
            get
            {
                return trackAndDisplay.R2D.ToString();
            }
            set
            {
                trackAndDisplay.R2D = int.Parse(value);
            }
        }

        public string R3D
        {
            get
            {
                return trackAndDisplay.R3D.ToString();
            }
            set
            {
                trackAndDisplay.R3D = int.Parse(value);
            }
        }

        public string Winner
        {
            get
            {
                return trackAndDisplay.Winner;
            }
            set
            {
                trackAndDisplay.Winner = value;
            }
        }
        public string DealerTotal
        {
            get
            {
                return Dealer.Total.ToString();
            }
            set
            {
                Dealer.Total = int.Parse(value);
            }
        }

        private void OnPropertyRaised(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public string Name
        {
            get
            {
                return player.Name;
            }
            set
            {
                player.Name = value;
                OnPropertyRaised("Name");
            }
        }

        public void CloseWindow(ICloseable window)
        {
            if (window != null)
            {
                window.Close();
            }
        }

        private void notifyUI(string param)
        {
            if (param.Equals("Dealcards"))
            {
                OnPropertyRaised("Pcard1");
                OnPropertyRaised("Pcard2");
                OnPropertyRaised("Dcard1");
                OnPropertyRaised("Dcard2");
                OnPropertyRaised("Pcard");
                OnPropertyRaised("Dcard");
            }
            else if (param.Equals("Dealer"))
            {
                OnPropertyRaised("DealerTotal");
                OnPropertyRaised("Dcard");
            }
            else if (param.Equals("player"))
            {
                OnPropertyRaised("PlayerTotal");
                OnPropertyRaised("Pcard");
            }
            else if (param.Equals("Scoreboard1"))
            {
                OnPropertyRaised("R1P");
                OnPropertyRaised("R1D");
            }
            else if (param.Equals("Scoreboard2"))
            { 
                OnPropertyRaised("R2P");
                OnPropertyRaised("R2D");
            }
            else if (param.Equals("Scoreboard3"))
            { 
                OnPropertyRaised("R3P");
                OnPropertyRaised("R3D");
            }
            else if (param.Equals("Winner"))
            {
                OnPropertyRaised("Winner");
            }
            else 
            {
                OnPropertyRaised("PlayerTotal");
                OnPropertyRaised("DealerTotal");
            }
    
        }
    }
}

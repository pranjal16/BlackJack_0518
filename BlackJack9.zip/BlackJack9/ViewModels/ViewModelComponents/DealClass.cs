﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace BlackJack.ViewModels.ViewModelComponents
{
    public class DealClass : ICommand
    {
        private Cards _cards = null;
        private Player _player = null;
        private Dealer _dealer = null;
        public event EventHandler CanExecuteChanged; 

        public DealClass(Cards cards, Player player, Dealer dealer)
        {
            _cards = cards;
            _player = player;
            _dealer = dealer;
        }      

        bool ICommand.CanExecute(object parameter)
        {
            return true;
        }

        void ICommand.Execute(object parameter)
        {
            try
            {
                _cards.Deal();
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Unexpected Error in Shuffle!, Please press end game! ");
            }
        }

    }
}

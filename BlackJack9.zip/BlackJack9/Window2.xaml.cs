﻿using BlackJack.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BlackJack
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public readonly MyViewModel _viewModel;
        public Window2()
        {
            InitializeComponent();
            _viewModel = new MyViewModel();
            // The DataContext serves as the starting point of Binding Paths
            DataContext = _viewModel;
        }

        private void OpenWindow(object sender, RoutedEventArgs e)
        {
            MainWindow window1 = null;
            try
            {
                window1 = new MainWindow(_viewModel);
                window1.Show();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                if (window1.IsActive)
                {
                    window1.Close();
                }
                App.Current.MainWindow.Close();

            }
            this.Close();
        }
    }
}
